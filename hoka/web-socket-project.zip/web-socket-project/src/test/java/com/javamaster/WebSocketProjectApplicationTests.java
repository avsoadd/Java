package com.javamaster;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WebSocketProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
